Prereqs
=======

Install the [PHP Stomp client](http://www.php.net/manual/en/book.stomp.php) 
library.

Pear users can install it by running:

    pear install pecl.php.net/stomp

Then you should add "extension=stomp.so" to php.ini
